# -*- mode: python; coding: utf-8; -*-
from django import forms
from django.conf import settings
from django.utils.translation import ugettext_lazy as _

__author__ = '$Author:$'
__revision__ = '$Revision:$'

# place form definition here